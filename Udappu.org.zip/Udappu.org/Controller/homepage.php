<?php
require_once('../Model/dbConn.php');
$posts=getAllPosts();
$events=getAllEvents();
