<?php
class AdminPostImage
{
    private $postID;
    private $adminID;

    public function __get($name)
    {
        return $this->$name;
    }

    public function __set($name, $value)
    {
        $this->$name=$value;
    }
}
