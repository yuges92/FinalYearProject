<?php require_once '../Controller/viewImage.php'; ?>
<img class="imgBig" src="<?= $image->folder_Name ?>/<?= $image->file_Name?>"/>
