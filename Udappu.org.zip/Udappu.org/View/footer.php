<div class="">
  <footer class="text-center">
     Udappu Community © 2017
  </footer>
</div>
