
  <div class="">
    <form class="" action="../View/searchResult.php" method="get">
      <div class="input-group">
        <input class="form-control" type="text" name="search" value="" placeholder="Search Members" required>
        <div class="input-group-btn">
          <input class="btn btn-default" type="submit" value="Search">
        </div>
      </div>
    </form>
  </div>
